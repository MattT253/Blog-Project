import React from 'react';

function Home (){
	return <h1>Blog app</h1>
}

export default Home;