import dotenv from "dotenv";

dotenv.config({ path: "./config.env" });
